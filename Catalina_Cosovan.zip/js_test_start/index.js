const setup = () => {
    let staatVanKip = document.getElementById("staatVanKip");
    staatVanKip.autofocus;

    let letter = document.getElementById("letter");

    letter.addEventListener("change", aantalLetter);

    staatVanKip.addEventListener("click", uitvoeren);
    staatVanKip.addEventListener("change", uitvoeren);
}

const uitvoeren = () =>
{
    let foto = document.getElementById("img");
    let fotoClasses = foto.classList;
    let staatVanKip = document.getElementById("staatVanKip");
    let opties = staatVanKip.options;
    let display = document.getElementById("img");
    let geselecteerdText = "";

    if(opties.selectedIndex === 1) {
        geselecteerdText = "met ei";
    } else{
        geselecteerdText = "zonder ei";
    }

    foto.classList.toggle("hidden");

    if(opties.selectedIndex === 1)
    {
        fotoClasses.add("with-egg");
        display.textContent = `Hierboven, een kip ${geselecteerdText}`;
    }
    else if(opties.selectedIndex === 2) {
        display.textContent = `Hierboven, een kip ${geselecteerdText}`;
    } else {
        display.textContent = "";
    }
}

const aantalLetter = () => {
    let letter = document.getElementById("letter").value;
    let text = document.getElementById("note");
    let aantal = 0;
    for(let i = 0; i < text.length; i++) {
        if(text[i].equals(letter)){
            aantal++;
        }
    }

    text.innerHTML = `<br> Letter "${letter}" komt ${aantal} keer voor in bovenstaande zin.`;
}

window.addEventListener("load", setup); 